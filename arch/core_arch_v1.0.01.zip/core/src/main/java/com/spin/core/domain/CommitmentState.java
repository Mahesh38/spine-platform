package com.spin.core.domain;

public enum CommitmentState {
    CREATED,
    ACTIVE,
    FULFILLED,
    VIOLATED;
}
